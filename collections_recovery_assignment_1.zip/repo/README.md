# Collections Recovery — Data Analyst Assignment

**Mission:** the business reports "recovery has improved by 11% month-on-month." Leadership isn't convinced. This repo determines what actually happened, why, whether the 11% is real, and where a ₹10 Cr investment should go — reconstructed independently from the raw `collections_30k_dataset`, with every conclusion traceable back to a query.

**Headline finding:** the 11% is a real number computed on real data — but it is a rebound off an unusually weak February, not a sustained trend. A linear regression across the 7 complete months in the extract (Jan–Jul 2026) returns **p = 0.89**; a full multivariate logistic regression on 89,071 account-months (controlling for month, risk segment, loan type, DPD bucket, attempt count, and channel touches simultaneously, with standard errors clustered by account) confirms the month effects are **jointly indistinguishable from zero (cluster-robust Wald p = 0.659)** — and a power analysis confirms the test was strong enough to have caught an effect of that scale if one existed. See `reports/executive_memo.docx` for the two-page summary, or the dashboard link below for the 60-second version.

## Start here

| I want to... | Go to |
|---|---|
| Read the 2-page executive summary | `reports/executive_memo.docx` |
| See the one-screen leadership dashboard | `dashboard/index.html` (open in a browser) |
| Understand every data-quality issue found | `reports/data_quality_report.md` |
| See the full reasoning with runnable code | `notebook/analysis.ipynb` |
| Reproduce every number from raw SQL | `sql/00_load_raw.sql` → `sql/06_investment_analysis.sql` |
| See the production architecture design | `reports/production_architecture.md` + `diagram/architecture.html` |

## Repository structure

```
dataset/                    Raw source CSVs (17 tables) + original README/data dictionary
sql/                        Reproducible SQL pipeline, DuckDB dialect, run in order 00 → 06
  00_load_raw.sql             Load all 17 CSVs into raw_* tables, unmodified
  01_clean_dimensions.sql     Clean borrowers / agents / vendors / campaigns / accounts
  02_clean_events.sql         Clean calls / dispositions / whatsapp / payments / etc.
  03_golden_build.sql         Assemble the Golden analytical layer + cleaning-impact audit
  04_metrics.sql              Independent metric definitions (Question 3) + monthly trend
  05_forensics.sql            Reproducible evidence for Part 2, findings A–G
  06_investment_analysis.sql  Supporting queries for the ₹10 Cr recommendation
golden/                     Golden dataset, exported as CSVs (one file per clean_*/metric_* table)
notebook/
  analysis.ipynb              Full analysis notebook — runs sql/00-06, reproduces every number,
                               includes the multivariate regression and the trend chart
  build_notebook.py           Generates analysis.ipynb programmatically (nbformat) — re-run this
                               after editing analysis logic, then re-execute with nbconvert
reports/
  data_quality_report.md      Part 2 — every data-quality issue, detection, treatment, impact
  performance_reconstruction.md  Q1 & Q3 — what happened, is the 11% real
  statistical_investigation.md   Part 3 — drivers, named biases, multivariate confirmation
  counterfactual_methodology.md  Part 4 — DiD design for a targeting-strategy change
  investment_recommendation.md   Q4 — where the ₹10 Cr should go, with ROI scenarios
  production_architecture.md     Part 5 — production pipeline design (narrative)
  executive_memo.docx            2-page leadership memo (What/Why/Confidence/Action/Impact)
  build_memo.js                  docx-js script that generates executive_memo.docx
dashboard/
  index.html                  One-screen executive dashboard (also published as a hosted page)
diagram/
  architecture.html           Production architecture diagram (Raw→Staging→Clean→Golden→
                               Feature→Metrics→Dashboard, with DQ checks and lineage)
```

## How to reproduce everything

```bash
# 1. Build the working database from raw CSVs through every cleaning/metric stage
python3 -c "
import duckdb
con = duckdb.connect('analysis.duckdb')
for f in ['sql/00_load_raw.sql','sql/01_clean_dimensions.sql','sql/02_clean_events.sql',
          'sql/03_golden_build.sql','sql/04_metrics.sql','sql/05_forensics.sql','sql/06_investment_analysis.sql']:
    con.execute(open(f).read())
"

# 2. Re-run the full notebook end to end (regenerates panel.csv and recovery_trend.png)
cd notebook && jupyter nbconvert --to notebook --execute --inplace analysis.ipynb
```

Everything downstream (the reports, the dashboard, the memo) was written from the numbers this pipeline produces — nothing was hand-typed from a spreadsheet.

## The four questions, answered

1. **What happened?** Nothing, operationally. Recovery, contact rate, PTP rate, PTP kept rate, and recovery-per-agent-hour are all flat across the 7 complete months in this extract, within normal ~4% month-to-month noise. → `reports/performance_reconstruction.md`
2. **Why did it happen?** No tested driver (agent, tenure, vendor, channel, campaign, attempt frequency, targeting strategy, targeting priority) shows an effect distinguishable from noise — confirmed by both single-factor tests and a full multivariate regression. Geography and language could not be tested (data gaps). → `reports/statistical_investigation.md`
3. **Is the reported 11% improvement real?** No — it's a real number from a real month-pair, but it's a rebound off an unusually weak February, not a trend. → `reports/performance_reconstruction.md`
4. **Where should the ₹10 Cr go?** WhatsApp/digital engagement, deployed as a gated two-phase investment (₹1.2 Cr randomized pilot, then ₹8.8 Cr scaled rollout conditional on the pilot proving a real, significant lift) — because it's the only lever with even a weak positive signal, and the cheapest to test properly before betting the rest of the budget. → `reports/investment_recommendation.md`

## A note on trust

This dataset was built to be messy on purpose, and this analysis treats every existing definition, every table, and every "clean-looking" column as a hypothesis to test rather than a fact to accept — including some traps that look like standard data-cleaning moves but are wrong here (e.g. `payment_reference` looks like a natural dedup key and is not one — see `reports/data_quality_report.md`, Finding A). Every claim in the reports is labeled **Fact**, **Strong Evidence**, **Correlation**, or **Hypothesis** so a reader can calibrate how much weight to put on it.
