# Part 5 — Production Analytics Design

Diagram: `diagram/architecture.html` (also exported as `diagram/architecture.svg`).

## 1. Pipeline stages

```
RAW -> STAGING -> CLEAN -> GOLDEN -> FEATURE -> METRICS -> DASHBOARD
```

- **Raw:** exact, append-only landing of every source system's events/extracts (calls, payments, WhatsApp/SMS webhooks, field-visit app exports, core-banking account/status feeds, HR/vendor rosters). No transformation. Partitioned by source + ingestion date. Immutable — a bad upstream record is never edited here, only superseded by a later raw record.
- **Staging:** typed, schema-validated version of Raw (correct types, parsed timestamps with source timezone preserved as its own column, source system tagged). This is where a **data contract** is enforced (§2) — records that fail the contract are quarantined here, not silently dropped or silently let through.
- **Clean:** de-duplication and canonicalization per the documented rules in `sql/01_clean_dimensions.sql` / `sql/02_clean_events.sql` (drop exact duplicate rows on primary key; canonicalize disposition-code synonyms; reconcile — not silently overwrite — conflicting status sources). Every row that is dropped or altered is logged to a `_rejected` / `_corrected` shadow table with a reason code, mirroring the Raw → Rejected/Corrected → Golden flow the assignment asks for.
- **Golden:** one trustworthy row per business entity/event, joined to just enough dimension context to be usable, with data-quality flags (e.g. `identity_conflict_flag`, `status_source_conflict_flag`, `attributes_low_confidence`) carried through rather than hidden. This is the only layer analysts and the metrics layer are allowed to query directly.
- **Feature:** account-month (or account-week) grain rollups used by multiple metrics — e.g. `accounts_worked`, `accounts_answered`, `n_ptp`, `n_kept`, `agent_hours`, `recovery_amount` — computed once and reused, so every downstream metric agrees on the same underlying counts instead of each dashboard re-deriving them slightly differently.
- **Metrics:** the named, versioned metric definitions (contact rate, RPC, PTP rate, PTP kept rate, recovery rate, recovery/account, recovery/agent-hour, cost/rupee recovered, channel conversion) computed from Feature tables, with the definition text itself stored as metadata (see §3) so "how is this number computed" is answerable by the system, not by asking an analyst.
- **Dashboard:** serves pre-aggregated Metrics only — never queries Clean/Golden directly — so dashboard latency and load are decoupled from the size of the raw event tables.

## 2. Data contracts

Each source feed gets a contract (schema + semantics) enforced at Staging:
- **Required fields and types** (e.g. `payments.amount` must be numeric, non-negative, non-null; `payments.event_at` must be a valid timestamp not in the future).
- **Primary key declaration** and an explicit **uniqueness SLA** ("`payment_id` is expected unique; violations quarantined and alerted, not silently deduped in Staging" — deduplication is a documented Clean-layer decision, not something that happens invisibly upstream).
- **Enum contracts** for coded fields (`call_status`, `disposition_code`, `payment_status`) — a new code value is a **breaking-contract event**, routed to quarantine + alert, not auto-accepted (this is exactly the class of problem that produced the PTP/PROMISE_TO_PAY synonym issue in Part 2).
- **Timezone contract:** every timestamp field must declare its timezone unambiguously (a stable per-entity value, not a per-event free choice) — this directly targets the timezone inconsistency found in Part 2, Finding C.
- **Referential contract:** foreign keys (`agent_id`, `account_id`, `campaign_id`, `vendor_id`) must resolve against their owning dimension at Staging time; unresolvable FKs are quarantined, not silently joined as NULL downstream.

## 3. Primary keys & metric definitions as registered metadata

- Every Golden table has one declared, enforced primary key (see the grain notes in `sql/03_golden_build.sql`). Where a natural key turned out unsafe in this project (`payment_reference`, `employee_code`) that decision — and why — is recorded next to the table definition, not just in an analyst's head.
- Metric definitions live in a version-controlled **metrics registry** (name, SQL, owner, valid-from date, denominator definition). This directly fixes the "denominator manipulation" risk (Part 2, Finding G): a metric's denominator is looked up from the registry, not chosen ad hoc per dashboard.

## 4. Lineage, incremental processing, late-arriving data, backfills

- **Lineage:** each Golden/Feature/Metric row carries the Raw batch id(s) that produced it, so "why does this number look wrong" can be traced back to a specific ingestion run.
- **Incremental processing:** Staging→Clean→Golden runs incrementally on new Raw partitions (by ingestion date), not full-table rebuilds — except Feature/Metrics for a given month are recomputed whenever new Golden data lands in that month (to absorb late arrivals, next point).
- **Late-arriving events:** this dataset already demonstrates the need — duplicate `call_id`s where a "corrected" copy arrives days after the original (Part 2, Finding J). The pipeline keeps a **watermark** per entity (e.g. "Golden `calls` for month M is considered final 5 days after month-end") and reprocesses Feature/Metrics for a month if Golden rows for that month change after first computation, rather than assuming month M is closed the instant the calendar turns over.
- **Backfills:** because Clean/Golden logic is expressed as pure SQL over Staging (not a stateful streaming transform), any change to a cleaning rule (e.g. discovering a new disposition-code synonym) can be replayed over full history without needing to "undo" anything — Raw is immutable, so Clean/Golden/Feature/Metrics can always be rebuilt from scratch for any historical partition.

## 5. Data-quality checks & monitoring

Automated checks run at Staging→Clean and Clean→Golden boundaries, each mapped to a Part 2 finding so regressions are caught automatically instead of rediscovered by a leadership question:

| Check | Fires when | Maps to |
|---|---|---|
| Row-count reconciliation (raw vs. golden) outside expected dedup range | > X% of rows dropped in a run | Findings A, E, H, J |
| Primary-key uniqueness on every Golden table | Any duplicate | Findings A, J |
| Enum-drift detector on coded fields | A `disposition_code`/`call_status`/`payment_status` value never seen before appears | Finding D |
| Cross-source status reconciliation | `accounts.status` vs. latest `account_status_history.status` disagree | Finding I |
| Denominator-definition assertion | A metric is queried/rendered without its registered denominator | Finding G |
| Monthly completeness check | Current month has < (days elapsed / days in month) × normal daily volume | Finding K — would have automatically flagged "August is partial" instead of letting it render as a 74.8% "decline" |
| Distribution drift (mix stability) | Risk-segment / loan-type / channel share moves > N pp month over month | Finding F — would auto-flag if a *real* mix shift ever does occur |

**Anomaly detection:** kept deliberately simple per the assignment's stated preference — a rolling 7-observation z-score / control-chart on each headline metric (the same test used in `04_metrics.sql`'s trend check: is this month's value more than ~2 standard deviations from the trailing mean?), not a black-box model. This alone would have caught the "11% MoM" framing problem: February's -9.1% and March's +11.0% both sit within the normal noise band once a control chart is drawn, and neither would fire an anomaly alert — which is itself the correct, honest signal ("this is noise, not news") that a well-designed monitoring system should give leadership before a headline number gets reported.

## 6. Why this is practical for an engineering team to build

- Every stage is a pure, replayable transformation over the stage before it (no hidden state, no manual edits) — this project's `sql/00`–`sql/05` files are literally an initial implementation of Raw→Staging(≈Raw here, since source data needed no type-casting)→Clean→Golden→Metrics, runnable end-to-end with DuckDB today and portable to a warehouse (Snowflake/BigQuery/Databricks) by swapping `read_csv_auto` for the platform's native ingestion.
- The data-quality checks in §5 are simple SQL assertions, not custom code — they can be wired into any standard orchestrator (Airflow/Dagster) as post-task checks with no new tooling.
