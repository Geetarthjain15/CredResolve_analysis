# Performance Reconstruction — What Happened, Why, and Is the 11% Real?

This answers assignment Questions 1–3. All figures are computed on the **Golden** (de-duplicated) dataset — see `sql/03_golden_build.sql` and `sql/04_metrics.sql` — and restricted to the 7 complete calendar months in the extract (January–July 2026). August 2026 is excluded from trend comparisons because it is a partial month (see Data Quality Report, Finding K).

---

## 1. What happened? [monthly recovery, Golden data]

| Month | Recovery (Rs) | MoM change |
|---|---:|---:|
| Jan 2026 | 187,229,128 | — |
| Feb 2026 | 170,142,548 | **-9.13%** |
| Mar 2026 | 188,912,374 | **+11.03%** |
| Apr 2026 | 175,137,975 | -7.29% |
| May 2026 | 184,250,282 | +5.20% |
| Jun 2026 | 175,559,657 | -4.72% |
| Jul 2026 | 187,242,290 | +6.65% |
| Aug 2026 *(partial, 8 of 31 days)* | 47,109,700 | *(-74.8%, artifact — see Finding K)* |

**[Fact]** Mean monthly recovery across the 7 complete months is **Rs 18.12 Cr**, with standard deviation **Rs 0.74 Cr** — a coefficient of variation of **4.1%**. Every month sits within about one standard deviation of the 7-month mean.

**[Fact]** A linear regression of monthly recovery against time (Jan=0 … Jul=6) gives slope = +Rs 222,000/month, r² = 0.004, **p = 0.89**. This is statistically indistinguishable from a flat line — there is **no detectable trend**, upward or downward, across the observed window.

**[Fact]** The one month-pair that shows a ~11% increase is **February → March** (+11.03% in Golden data; +10.99% even before any de-duplication — the duplicate-payment issue does not manufacture this number). This is almost certainly the pair behind the business's "recovery improved 11% month-on-month" claim.

## 2. Is the reported 11% improvement real? [Fact + Strong Evidence]

**No — not as evidence of a genuine, sustained improvement in operational performance.** It is real in the narrow arithmetic sense (March's total was 11.03% above February's), but it is misleading as a headline because:

1. **February was the low point of the whole window (-9.13% vs January), not a normal baseline.** March's "+11%" is mean-reversion back toward January's level, not a new high. March (Rs 188.9 Cr) is only **+0.90%** above January (Rs 187.2 Cr) — essentially flat if you compare like-for-like starting points instead of starting from the trough.
2. **Every other consecutive month-pair in the same window shows swings of similar magnitude in both directions** (-9.1%, +11.0%, -7.3%, +5.2%, -4.7%, +6.6%) — a ~4–11% swing either way is the *normal* month-to-month noise band for this book, not a signal.
3. **The full-window trend test is flat (p = 0.89).** If the business's operational changes were genuinely improving recovery, we would expect the later months to sit above the earlier months on average. They do not — July (Rs 187.2 Cr) is statistically the same as January (Rs 187.2 Cr).
4. **We could not find any operational driver that moved in step with the Feb→Mar swing** — see §4 below and `reports/statistical_investigation.md`. Portfolio mix was flat, channel mix was flat, agent and vendor performance were flat. There is no candidate cause visible in the data for a genuine 11% operational jump.
5. Contact rate (Golden `metric_monthly_funnel`) shows the same pattern: 23.6% (Jan) → 23.0% (Feb) → 23.6% (Mar) → … flat within noise across all 7 months (trend test p = 0.97).

**Conclusion:** the 11% figure is a **real but cherry-picked comparison of a rebound off an unusually weak February**, not evidence of improving collections performance. Classified as **Fact** (the number and its arithmetic origin) with **Strong Evidence** (not Fact, because we cannot rule out an unobserved genuine cause with 100% certainty) that it does not represent sustained improvement.

**Confirmatory check.** A multivariate logistic regression on 89,071 account-month observations (payment outcome ~ month + risk segment + loan type + DPD bucket + attempt count + channel touches, all simultaneously — `reports/statistical_investigation.md` §2b–2c) finds the six month fixed effects **jointly indistinguishable from zero**, even after giving the model every chance to explain the Feb/Mar swing through mix or intensity differences, and after correcting for the fact that the panel has repeated observations per account (cluster-robust Wald test, clustered by account: χ² = 4.13, df = 6, **p = 0.659**; naive likelihood-ratio test agrees almost exactly at p = 0.658). Every month's 95% confidence interval for its odds ratio spans 1.00. A power analysis confirms this isn't a test that was too weak to find anything: with ~12,724 account-months per calendar month, the design has 80% power to detect a swing as small as ±0.94pp (≈12% relative) in the underlying payment rate — on the same scale as the swing needed to produce a genuine ~11% recovery change — and the largest month effect actually observed (~0.65pp) is smaller than that. This is the single strongest and most conclusive piece of evidence in the whole analysis that there is no real trend to explain.

## 3. When and where did performance change?

**[Fact]** It didn't, materially — not in aggregate, and not in any of the sub-cuts we could trust (risk segment, loan type, channel, vendor, dpd bucket). See `reports/statistical_investigation.md` for the full driver-by-driver breakdown. The only "changes" found were in the low single digits of statistical noise.

**[Fact]** The one place we found something to flag is **data reliability**, not performance: recovery reported to leadership before this exercise was inflated by ~1.93% from duplicate payment rows, and any campaign-level attribution of that recovery is built on an attribution window that, depending on the choice made, changes the attributed campaign for 27% of attributable payments and cannot attribute 68% of all successful payments to any campaign at all (Data Quality Report, Finding B).

## 4. Which metrics are genuinely improving, and which are misleading?

| Metric | Trend across Jan–Jul (Golden) | Verdict |
|---|---|---|
| Total recovery (Rs) | Flat, p = 0.89 | **Misleading if MoM is quoted** — noise, not trend |
| Contact rate | 22.5%–24.0%, flat, p = 0.97 | Flat |
| PTP rate (accounts with a PTP ÷ accounts answered) | 13.9%–16.6%, no trend | Flat |
| PTP kept rate | 48.5%–50.7%, no trend | Flat |
| Recovery per account | Rs 76.4k–80.5k, tracks total recovery — no independent trend | Flat |
| Recovery per agent-hour | Rs 16,100–17,000, flat | Flat |
| Cost per rupee recovered | **Not computable** — no cost/spend data exists in this dataset (no wages, telephony per-minute rates, messaging costs). Any number quoted for this metric elsewhere is fabricated or sourced outside this dataset. | **Data gap** |
| Channel conversion (14-day payment after touch, by campaign channel) | 2.2%–4.8% across all channel × segment cells, differences within sampling noise (see statistical investigation) | Flat |

**Bottom line for leadership:** based on this dataset, collections performance over the last 7 complete months has been **stable, not improving and not declining**. The "11% MoM improvement" headline should be retired in favor of a rolling trend view that would have shown this immediately.
