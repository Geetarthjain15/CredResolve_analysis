# Data Quality Report
### Collections Analytics — `collections_30k_dataset`

This report documents every material data-quality issue found in the raw dataset, how it was detected, how it was treated in the Golden layer, and its quantified business impact. Full reproducible SQL for every check is in `sql/05_forensics.sql`; the cleaning logic is in `sql/01_clean_dimensions.sql` and `sql/02_clean_events.sql`.

Every finding below is labeled **Fact** (directly observed in the data, not open to interpretation), **Strong Evidence** (observed pattern with a well-supported but not 100%-certain explanation), **Correlation** (an association observed without a causal claim), or **Hypothesis** (a plausible but unverified explanation).

---

## 1. Summary table

| # | Issue | Status | Business impact |
|---|---|---|---|
| A | Duplicate payment rows | **Fact — Confirmed** | Rs 2.59 Cr (1.93%) of reported recovery is double-counted if raw data is used as-is |
| B | Payment attribution is undefined | **Fact — Confirmed** | Any "recovery by campaign/channel" number is a modeling choice, not a measurement — window choice changes attributed campaign for the majority of payments that can be attributed at all |
| C | Timezone field is unreliable | **Fact — Confirmed**, immaterial to trend | 73.5% of accounts show >1 timezone label across their own calls; makes calling-time / compliance-window analysis unsafe |
| D | Vendor / disposition code drift | **Not confirmed** for vendors; **Confirmed** for one disposition synonym | Vendor call outcomes are statistically identical across all 15 vendors; `PTP` and `PROMISE_TO_PAY` are the same event under two labels |
| E | Agent identity is unresolvable | **Fact — Confirmed, severe** | Agent-dimension attributes (name, employee code, team, vendor) cannot be trusted; only `agent_id` is safe to use |
| F | Portfolio mix shift | **Not confirmed** | Risk segment / loan type mix of paying accounts is stable within ±3pp every month — rules out mix shift as a driver |
| G | Denominator manipulation | **Not confirmed** in raw targeting data, but **demonstrated as a live risk** | The same July numerator produces a contact rate of 7.8%, 22.8%, or 31.1% depending purely on which denominator is chosen |
| H | Borrower identity is unresolvable | **Fact — Confirmed, severe** (not in the original A–G list, found independently) | 77% of distinct borrowers have internally conflicting name/phone/email/city — geography and demographic cuts carry material uncertainty |
| I | `accounts.status` conflicts with event history | **Fact — Confirmed, severe** | 85.7% of accounts with a status history disagree between the dimension table and the latest logged event — no single source of truth for "is this account still active" |
| J | Duplicate `call_id` / `whatsapp_event_id` rows | **Fact — Confirmed** | 1,350 duplicate call rows (-1.48%), 600 duplicate WhatsApp event rows (-1.0%) — inflates activity/volume KPIs if uncorrected |
| K | August 2026 is a partial month | **Fact — Confirmed** | Data extract stops 8 Aug 2026; naively trending August looks like a 74.8% collapse versus July — it is a calendar artifact, not a business event |

---

## 2. Detailed findings

### A. Duplicate payments — CONFIRMED

**Detection.** `payment_id` should be a unique event key. 500 of 25,500 rows (2.0%) share a `payment_id` with another row. 486 of those 500 pairs are byte-for-byte identical across every column; the other 14 differ only in `payment_reference` being NULL in one copy — the same underlying event either way.

**A trap we found and avoided:** `payment_reference` is *not* a safe de-duplication key. Grouping by `payment_reference` instead of `payment_id` would have collapsed 3-, 4-, and 5-row groups of *genuinely different* payments (different `payment_id`, different `amount`, different `event_at`, e.g. reference `TXN0000050468` legitimately covers three separate part-payments of ₹47,730.92 / ₹40,930.14 / ₹127,454.47). Doing this would have thrown away roughly ₹17 Cr of real recovered cash — a bigger and *opposite-direction* error than the one we were looking for. This is exactly the kind of "cleanest-looking table is not the most reliable" trap the assignment warns about: `payment_reference` looks like a natural key and is not one.

**Treatment.** De-duplicated on `payment_id`, keeping the copy with a non-null `payment_reference`. See `clean_payments` in `sql/02_clean_events.sql`.

**Business impact.**

| | Naive (raw) | Golden (de-duplicated) |
|---|---:|---:|
| SUM(amount) where status = SUCCESS | Rs 1,341,485,926 | Rs 1,315,583,965 |
| Overstatement | | **Rs 25,901,962 (1.93%)** |

### B. Attribution errors — CONFIRMED (methodology risk)

**Detection.** `payments` carries no `campaign_id`, `call_id`, or channel of its own — attributing a payment to "the campaign that caused it" requires an analyst to choose a look-back window over `calls`. We tested two reasonable windows:

| Look-back window | Successful payments attributable to *some* campaign touch |
|---|---:|
| 3 days | 723 / 17,534 (4.1%) |
| 30 days | 5,535 / 17,534 (31.6%) |

4,812 payments (27% of all successful payments) are attributable under a 30-day window but not a 3-day window — meaning **the attributed campaign, and therefore any "campaign X drove ₹Y" claim, is largely an artifact of the window an analyst picks**, not a measured fact. More fundamentally: **68% of successful payments have no traceable campaign touch within 30 days at all.** Most of the cash collected in this business cannot be safely attributed to any specific collections activity with the tables provided — it may be auto-debit, organic repayment, or a touch that happened further back than any reasonable attribution window. Any campaign-level ROI figure built on this data should be treated as **Hypothesis-strength at best**, not Fact.

**Treatment.** The Golden layer does **not** invent a payment→campaign attribution. `golden_payments` carries the account-level context (risk segment, DPD bucket) needed for cohort analysis but deliberately leaves campaign attribution as an explicit, parameterized step (see `sql/05_forensics.sql`, check B) so any consumer must consciously choose and document a window rather than inherit a silent default.

### C. Timezone problems — CONFIRMED, immaterial to the recovery trend

**Detection.** `accounts.timezone` and `calls.timezone` each take one of three values (`UTC`, `Asia/Kolkata`, `Asia/Dubai`), roughly evenly split. But:
- 20,874 of 28,408 accounts with calls (73.5%) show calls tagged with **more than one** timezone label across their own call history.
- 60,887 of 91,350 calls (66.6%) have a `timezone` that disagrees with their own account's `timezone`.

This means `timezone` is being stamped per-event, essentially at random, rather than being a stable property of the account/borrower's real location. **We could not find any way to trust this field for geography-linked timezone inference.**

**Why it doesn't explain the recovery trend.** Call volume by hour-of-day is close to uniform (±3%) in every timezone label, whether or not you convert using the label. So although the field is broken, it happens not to distort the monthly recovery numbers in *this* extract. It **would** distort any "which hour/day gets the best contact rate" or RBI calling-window compliance analysis (permitted calling hours in India are typically 8am–7pm) — we recommend this NOT be relied upon for compliance reporting until fixed at the source.

**Treatment.** Carried through unchanged with a documented caveat; not used as an input to any monthly trend metric.

### D. Vendor mapping / disposition code changes — PARTIALLY CONFIRMED

**Detection — vendors: not confirmed.** `call_status` (`ANSWERED`/`FAILED`/`VOICEMAIL`/`NO_ANSWER`/`BUSY`) is used identically by all 15 telephony vendors, and the ANSWERED rate is statistically indistinguishable across vendors (range 19.3%–20.5%, no vendor is an outlier). `vendor_telephony.schema_version` (v1/v2/v3) does not correspond to any vocabulary or rate difference either. **We found no evidence of a vendor-driven code-mapping problem.**

**Detection — disposition codes: confirmed.** `call_dispositions.disposition_code` contains **`PTP` and `PROMISE_TO_PAY` as two separate values describing the same event**, co-occurring in a near-constant ~50/50 split in every single month (e.g. Jan: PROMISE_TO_PAY 588 vs PTP 566; Jul: PROMISE_TO_PAY 534 vs PTP 519). `disposition_version` (legacy/v1/v2) does **not** correlate with calendar time — all three tags span the entire Jan–Aug window — so it cannot be used as a "before/after a system migration" signal; it looks like arbitrary per-row metadata.

**Treatment.** Canonicalized `PROMISE_TO_PAY → PTP` in `clean_call_dispositions`. Any PTP-rate metric computed on the raw `disposition_code = 'PTP'` filter alone understates true PTP volume by roughly **half**.

### E. Agent identity problems — CONFIRMED, severe

**Detection.** `agents.csv` has 30,000 rows but only **1,000 distinct `agent_id`** — and `agent_id` is the *only* trustworthy key: it is what `calls`, `call_attempts`, `call_dispositions`, `agent_sessions`, `field_visits`, and `promises_to_pay` all use as their foreign key, with **zero orphaned agent_ids** in `calls`. The ~30 rows per `agent_id`, however, are not a clean change-history: `employee_code`, `agent_name`, `vendor_id`, `team`, and `status` are effectively **scrambled** across those rows. Example: `AGT0000367` appears 48 times with 48 different `employee_code`s and spans all 10 names in the company's name pool. Going the other direction is no better — `employee_code` is not a safe alternate key either: `EMP00900` alone maps to 46 different `agent_id`s with different names.

**Treatment.** `agent_id` is treated as the only reliable grain. For each `agent_id`, `clean_agents` reconstructs one "best-guess" attribute row using the mode (most frequent value) of `employee_code`/`agent_name`/`vendor_id`/`team`, tie-broken by most recent `updated_at`, and is explicitly flagged `attributes_low_confidence = TRUE`. **Any driver analysis that segments by agent `team` or `vendor_id` (rather than raw call/session-level `vendor_id`, which is reliable) should be read as directional only.**

### F. Portfolio mix changes — NOT CONFIRMED

**Detection.** We tracked the `risk_segment` and `loan_type` composition of accounts making successful payments, month by month. Both are flat: risk segment shares stay within LOW 24.2–27.6%, MEDIUM 22.5–26.2%, HIGH 23.1–26.8%, NPA 23.0–26.5% every month; loan type shares stay within 18.4–21.4% each, every month, for all 5 loan types. **There is no evidence the business acquired a materially different portfolio at any point in the observed window.** This rules out portfolio-mix shift as an explanation for any month-to-month swing in aggregate recovery.

### G. Denominator manipulation — NOT CONFIRMED in the data provided, but demonstrated as a real and present risk

**Detection.** `daily_targeting` — the closest thing we have to "the population the business considers in scope" — is flat at ~6,150 accounts/month split evenly across QUEUED/CONTACTED/SKIPPED/EXPIRED; we found no evidence unsuccessful accounts are being silently dropped from this particular table over time.

**However**, we could not see the business's own reporting queries, only the raw event data — so we cannot rule out denominator games happening *downstream* of this data. To make the risk concrete, we computed July's contact rate three defensible ways:

| Denominator definition | Contact rate |
|---|---:|
| Answered accounts ÷ whole portfolio (30,000) | 7.8% |
| Answered accounts ÷ accounts worked that month (10,278) | 22.8% |
| Answered accounts ÷ accounts still ACTIVE (7,539) | 31.1% |

**The same numerator produces a 4x range purely from denominator choice.** Any reported "conversion" or "contact rate" number must come with an explicit, fixed denominator definition — we recommend the business publish its denominator definition alongside every rate metric going forward (see Part 5 / data contracts).

### H. Borrower identity problems — CONFIRMED, severe (found independently, not in the original A–G checklist)

**Detection.** `borrowers.csv` has 30,600 rows but only 11,015 distinct `borrower_id`. For borrower_ids with more than one row, name/phone/email/city/state frequently disagree — up to 11 conflicting variants for a single `borrower_id` — the same identity-scrambling pattern as agents (finding E). 8,518 of 11,015 distinct borrowers (77%) have at least one internal conflict.

**Why this matters more than it might look.** Geography is an explicitly required investigation dimension (Part 2, Q2). With 77% of borrower records internally inconsistent on city/state, **any geography-cut of recovery performance carries material uncertainty** and should not be presented to leadership without this caveat.

**Treatment.** De-duplicated to one row per `borrower_id` (latest `updated_at`), with `identity_conflict_flag = TRUE` carried through to `golden_accounts` so downstream consumers can see which cuts are trustworthy.

### I. `accounts.status` vs. `account_status_history` — CONFIRMED, severe

**Detection.** `accounts.status` (the "current status" column on the account dimension) disagrees with the most recent status logged in `account_status_history` for **22,295 of 25,999 accounts that have any history (85.7%)**. There is no data-level way to tell which source is authoritative — both are internally self-consistent (no two rows in `account_status_history` show a genuine timestamp collision with different statuses), they simply don't agree with each other.

**Business impact.** Any metric that depends on "is this account currently active / closed / written off" (portfolio-size denominators, recovery-rate denominators, eligibility for further collections activity) is being computed against a dimension table that disagrees with the event log for the large majority of the book. **This is escalated as an open question for Engineering/Product — we did not silently pick a winner.**

**Treatment.** Both are retained: `status_snapshot` (from `accounts`) and `status_from_history` (from the event log, latest by `event_at`), with `status_source_conflict_flag` marking every disagreement.

### J. Duplicate `call_id` and `whatsapp_event_id` rows — CONFIRMED

**Detection.** `calls`: 91,350 rows / 90,000 distinct `call_id` (1,350 duplicate groups). 1,271 groups are byte-for-byte exact duplicates; 79 groups share a `call_id` but disagree on one field — either `agent_id` is NULL in one copy, or `event_at` differs by a few days with everything else identical (a re-logged echo, not a second real call). `whatsapp_events`: 60,600 rows / 60,000 distinct `whatsapp_event_id` (600 exact duplicates).

**Treatment.** De-duplicated to one row per key (see rules in `sql/02_clean_events.sql`). Any activity-volume KPI ("calls made", "WhatsApp messages sent") computed on raw data overstates true volume by ~1.5% and ~1.0% respectively.

### K. August 2026 is a partial month — CONFIRMED

**Detection.** The data extract ends 8 Aug 2026. Naive month-over-month comparison shows August "declining" 74.8% versus July — purely because August has 8 days of data instead of ~31. This is a **calendar-completeness artifact, not a business signal**, and would badly mislead anyone trending the metric without noticing.

**Treatment.** All monthly trend analysis in this project is restricted to the 7 complete months (January–July 2026); August figures are reported separately, explicitly labeled partial, and never plotted on the same trend line without a visual break.

---

## 3. What we did *not* find

- No evidence of **portfolio mix change** (Finding F).
- No evidence of **vendor-driven code drift** (Finding D, vendor half).
- No evidence of **denominator manipulation actually occurring** in the raw targeting data (Finding G) — though the risk is real and easy to demonstrate.
- No evidence of **Simpson's paradox** in the monthly recovery trend — a precondition for Simpson's paradox is a shifting subgroup mix, and we confirmed the subgroup mix (risk segment, loan type) is stable, so no paradox can be hiding in the aggregate.

## 4. Net effect of all cleaning on the headline recovery number

| | Amount |
|---|---:|
| Raw, naive SUM(amount) where status = SUCCESS (whole extract) | Rs 1,341,485,926 |
| Golden, de-duplicated SUM(amount) where status = SUCCESS (whole extract) | Rs 1,315,583,965 |
| Total correction | **Rs 25,901,962 (1.93% lower than reported)** |

This correction alone is *not* what explains the reported "11% improvement" — see `reports/executive_memo.docx` and `notebook/analysis.ipynb` §4 for the full explanation of that number.
