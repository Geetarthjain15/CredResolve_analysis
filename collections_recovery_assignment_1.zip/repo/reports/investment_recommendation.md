# Question 4 — Where should the ₹10 Cr go?

## 0. The uncomfortable finding this recommendation has to work around

Part 3 tested every lever the assignment asked about — agent, agent tenure, telephony vendor, channel, campaign, attempt frequency, targeting-strategy proxy, targeting priority — and **none of them showed a statistically detectable effect on outcomes** in this dataset (see `statistical_investigation.md`). That includes an important negative result specific to this question: **account-month payment rate is flat at ~7.5–7.6% whether an account was attempted 1 time or 4–6 times in a month.** That single finding rules out the naive version of two of the six options before we even start:

- **More collection agents** and **AI voice automation-as-pure-volume-scaling** both work by increasing attempt volume. If attempt volume doesn't move the outcome in the range we can observe, buying more of it (human or AI) will not mechanically buy more recovery. We are not recommending either option on that basis.
- **Better telephony infrastructure** — ruled out directly: all 15 vendors perform identically (19.3%–20.5% answer rate). There is no infrastructure-quality gap visible to close.
- **Field operations** — no evidence of superior effectiveness over phone/digital, and field visits are the most expensive channel per contact of the six (travel + agent time). Weakest cost-efficiency case of the six; not recommended as the primary bet.
- **Better borrower targeting** — the one proxy test we could run (targeting-strategy `v2`/`v3` vs `legacy`/`v1`, and `daily_targeting.priority` 1–10 vs. pay rate) found no effect (p = 0.79; priority range 7.3%–8.2%, flat). This is weak evidence (see caveats in `counterfactual_methodology.md`), but it does not support a confident bet either.

## 1. Recommendation: **WhatsApp / digital engagement**, deployed as a gated two-phase investment — not a single up-front commitment

**Why this option survives when the others don't:**

1. **It is the only lever with even a directional (not yet significant) positive signal in the data.** Account-month pay rate by WhatsApp touch count: 1 touch → 7.55%, 2 touches → 7.80%, 3–4 touches → 8.18% (monotonic, but not statistically significant at current volumes — 95% CI on the 1-vs-2 gap is roughly ±0.7pp against an observed 0.25pp difference). This is the one place in the whole investigation where more looks directionally better, not flat.
2. **There is real headroom.** 25,924 of 30,000 accounts (86%) have been reached by WhatsApp at least once, but at only **2.3 messages per account across the entire ~7-month window** — roughly one message every 13 weeks. Frequency, not reach, is the binding constraint, and frequency is the cheapest thing to change.
3. **It is dramatically cheaper to scale than any human-touch channel.** A WhatsApp/SMS message costs paise; a human or AI-voice call attempt costs rupees. Even a small true effect clears a much lower cost bar here than on any calling channel.
4. **It is reversible.** Unlike hiring agents or building field infrastructure, a messaging cadence can be turned up, turned down, or redirected within weeks, and it is naturally suited to a randomized controlled test before full commitment — which the data tells us we need (see below).

**Why we are not simply recommending "spend ₹10 Cr on WhatsApp" outright:** the dose-response signal above is directional, not proven. Given that *every other lever we tested also looked promising-until-tested and turned out flat*, committing ₹10 Cr on an untested assumption would repeat the exact mistake this whole assignment is about (see the "11% MoM" finding). So the recommendation is explicitly **phased and gated on a real experiment**.

## 2. Structure of the ₹10 Cr

### Phase 0 — Pilot & measurement (₹1.2 Cr, Months 1–3)

- Build a proper **randomized controlled test**: randomly assign a matched sample of ~13,000 already-reachable accounts to a ~3x cadence increase (from ~1 msg/quarter to ~1 msg/week) with AI-assisted personalization/sequencing (payment-link nudges, PTP reminders, negotiated-amount offers), vs. a held-out control kept at current cadence.
- Pre-register the outcome metric and window **before** looking at results, using a fixed attribution window (recommend 14 days, consistent with the metric definitions in `04_metrics.sql`) — to avoid the exact attribution-window-shopping problem documented in the Data Quality Report.
- Budget is dominated by platform/integration/AI-personalization build and a dedicated analytics owner, not message cost (incremental messages during the pilot cost on the order of ₹30,000 at ₹0.35/message — trivial against the platform build cost).

### Phase 1 — Scaled rollout (₹8.8 Cr, Months 4–15), **gated on Phase 0 showing a statistically significant, positive incremental lift**

- Extend the higher-cadence, personalized digital journey to the full 30,000-account book, including the 4,076 accounts never reached digitally.
- Fund 12 months of platform operations, ongoing AI personalization/orchestration development, and a reserve for iteration.
- If Phase 0 does **not** show a significant lift, the recommendation is to **stop here having spent ~₹1.2 Cr (12% of budget)**, not the full ₹10 Cr, and revisit the six options with a real experiment's worth of new evidence instead of another untested assumption.

## 3. Financial estimate (Phase 1, conditional on a successful Phase 0)

**Assumptions — explicitly not measured in this dataset, stated for transparency:**
- Messaging cost: ₹0.35 per WhatsApp/SMS send (blended, India Business-API pricing ballpark).
- "Incrementality factor": the correlational 14-day recovery attributed to a WhatsApp touch in this data is ₹2,545/touch (all touches, including non-paying ones — see `sql/05_forensics.sql`-style query in the notebook). Because this is correlational, not causal (most of it is probably payments that would have happened anyway — see attribution-window findings), we discount it heavily: **base case 8% truly incremental, downside 3%, upside 15%.** These figures are assumptions pending the Phase 0 experiment, not estimates from the data.
- Rollout adds roughly 2 incremental touches/account/month across all 30,000 accounts for 12 months = ~720,000 incremental touches/year.

| Scenario | Incremental value / touch | Expected incremental recovery (Year 1) | ROI on ₹10 Cr | Break-even |
|---|---:|---:|---:|---:|
| Downside (3% incrementality) | Rs 76 | **Rs 5.5 Cr** | -45% | ~22 months (misses Year 1) |
| **Base case (8%)** | Rs 204 | **Rs 14.7 Cr** | **+47%** | **~8–9 months** |
| Upside (15%) | Rs 382 | **Rs 27.5 Cr** | +175% | ~4–5 months |

Year 2+ costs drop sharply (mostly platform maintenance + messaging, on the order of Rs 1–1.5 Cr/year) once the Phase 1 build is complete, so ROI improves materially from Year 2 onward in every scenario except a Phase-0 stop.

## 4. Confidence and downside scenario

**Confidence: LOW–MEDIUM**, and we say so deliberately rather than dress up a guess as precision. The core input (incrementality factor) is an assumption, not a measurement — this dataset does not contain a true causal estimate of digital-engagement effect, only a weak, non-significant correlational one. That is exactly why Phase 0 exists: it converts this from a ₹10 Cr bet on an assumption into a ₹1.2 Cr bet on a question, with the other ₹8.8 Cr released only once the question has a real answer.

**Downside scenario:** Phase 0 finds no significant lift (plausible — every other lever tested this way came back flat). In that case the loss is capped at the Rs 1.2 Cr pilot spend (12% of the budget), and we would recommend the freed Rs 8.8 Cr be redirected to a fresh, similarly gated experiment on the next-best candidate (most likely a properly randomized test of AI-voice automation as a **cost-reduction** play at constant attempt volume, rather than a volume-scaling play — since Part 3 shows human agent identity carries no measurable skill premium, replacing a portion of human attempts with cheaper AI-voice attempts at the *same* volume is a legitimate cost-per-rupee-recovered improvement even though it would not be expected to grow gross recovery).

## 5. If forced to pick one channel today with zero further testing

If leadership will not accept a phased/gated structure and insists on a single irreversible ₹10 Cr commitment with no pilot, our answer is that **the data is insufficient to make that call responsibly** — every lever we could test came back statistically flat, and picking one anyway would be repeating the exact error (treating noise as signal) that produced the "11% MoM improvement" headline this assignment exists to investigate. The additional experiment required, at minimum, is the Phase 0 RCT described above; absent it, we would rather recommend the smallest, cheapest, most reversible bet (digital cadence) than the largest or least reversible one (field operations or a permanent headcount increase).
