# Part 4 — Counterfactual: "What would recovery have looked like without the targeting change?"

## 0. A note on the premise

The assignment asks us to **assume** the business changed its targeting strategy midway through the year and to design a methodology to estimate the counterfactual. We checked whether the data actually contains a clean, time-ordered targeting change to analyze, and it does not: `campaigns.strategy_version` (legacy/v1/v2/v3) is the only strategy-related field, and all four values are active **concurrently** throughout January–May 2026 (campaigns of every strategy_version launch in nearly every month) — there is no single cutover date to exploit. So this section does two things: (1) designs the methodology the business should use **the next time it makes a real, dated strategy change**, and (2) runs a weaker, clearly-caveated illustrative version of it on `strategy_version` as a stand-in, to show the method end-to-end and report what it would find in this dataset.

## 1. Methodology (for a real, dated strategy change)

**Setup.** Say the business flips targeting strategy for all new campaigns on a known date *T*.

- **Treatment group:** accounts/campaigns targeted under the new strategy (started ≥ *T*).
- **Control group:** accounts/campaigns that continued to be targeted under the old strategy logic after *T* — if none exist (a hard cutover with no holdout), use accounts with pre-*T* characteristics matched to the treated population as a synthetic control instead (see "Identification strategy" below).
- **Outcome:** 14–30 day post-touch conversion (SUCCESS payment within N days of a campaign touch — N fixed and disclosed, given the attribution-window sensitivity documented in the Data Quality Report).

**Identification strategy — Difference-in-Differences (DiD), matched.**

1. Match treated and control accounts on pre-period covariates that we know are stable and available: `risk_segment`, `dpd_bucket`, `loan_type`, and prior contact history (# calls/SMS/WhatsApp touches in the 60 days before *T*). Exact-match or coarsened-exact-match on these (the account volumes here comfortably support exact matching on a 4×5×5 grid).
2. Compute each group's average outcome in a pre-period window (e.g. the 60 days before *T*) and a post-period window (60 days after *T*).
3. DiD estimate = (Treated_post − Treated_pre) − (Control_post − Control_pre). This nets out any common time trend (seasonality, macro repayment conditions) that would otherwise be confused with the strategy's effect.
4. Report the DiD estimate with a standard error from a two-proportion (or linear probability) regression with account-level clustering, and a 95% CI.

**Confounders to control for / watch for:**
- **Simultaneous changes.** If telephony vendor, campaign volume, or agent staffing changed at the same time as *T*, the DiD will conflate them. Check for this exactly as we did in §Part 3 (mix/vendor/agent stability) before trusting the estimate.
- **Anticipation effects.** If campaigns were pre-announced, "control" accounts contacted just before *T* may already behave differently.
- **Regression to the mean.** If the new strategy specifically re-targets accounts that had recently underperformed (e.g. `PROMISE_BROKEN`), a naive pre/post comparison on that subgroup will show "improvement" from mean reversion alone, not the strategy. Matching + DiD on a stable covariate set (not on the trigger variable itself) protects against this — this is precisely the trap the aggregate Feb→Mar "11%" number falls into (see `performance_reconstruction.md`).
- **Attribution-window choice.** Must be fixed and disclosed before running the analysis (Data Quality Report, Finding B) — not tuned after seeing results.

**Assumptions required for this design to be valid:**
- Parallel trends: absent the strategy change, treated and control groups' outcomes would have moved together. Testable by checking pre-period trends are parallel (a placebo DiD on two pre-period windows).
- No spillover: contacting a "new-strategy" account doesn't change a "control" account's behavior (plausible here — no shared-resource constraint that we can see, e.g. accounts don't compete for a fixed pool of promise-to-pay agreements).
- Stable attribution window applied identically to both groups.

**Limitations:** DiD identifies an average treatment effect for the matched population, not necessarily the effect if the strategy were rolled out to the *whole* book (external validity depends on how representative the treated accounts were). With only a handful of months of data, standard errors on any monthly-grain DiD will be wide — we would recommend running this at weekly grain if the business wants a faster read.

## 2. Illustrative run on `strategy_version` (heavily caveated)

Because there is no real time-ordered cutover, we instead ran a **cross-sectional** comparison: group campaigns into "OLD" (legacy + v1, the two lower version tags) vs. "NEW" (v2 + v3), and compare 14-day conversion rate of accounts touched by each group, **stratified by `target_definition`** to hold the targeting *rule* constant (this is the closest thing to matching available with campaign-level, not account-level, treatment assignment).

| Strategy group | Accounts touched | Converted (paid within 14d) | Conversion rate |
|---|---:|---:|---:|
| OLD (legacy + v1) | 44,515 | 1,607 | **3.61%** |
| NEW (v2 + v3) | 43,059 | 1,540 | **3.58%** |

Two-proportion z-test: z = 0.267, **p = 0.79**. **No statistically detectable difference.**

**Why this is weak evidence, not strong evidence:** (1) it is cross-sectional, not before/after — "OLD" and "NEW" campaigns ran in the same months, so this cannot rule out that campaign strategy assignment itself correlates with account difficulty; (2) `strategy_version` may not correspond to any real chronological strategy rollout at all (we could not confirm what it represents beyond a label on the campaign); (3) it is not matched at the account level, only stratified by `target_definition`, so residual confounding by risk_segment/DPD within each stratum is possible (though Part 3 showed those are stable overall, which somewhat mitigates this). We report this result as **directional, illustrative context only** — it is consistent with the broader finding (Part 3) that no channel/campaign/agent-level factor shows a detectable effect in this data, but it should not be read as a rigorous causal test of any specific strategy change.

## 3. Bottom line

We do not have the data to answer "what would recovery have looked like without the targeting change" with confidence, because the premised change is not identifiable in the extract provided. The methodology above is ready to run the moment the business can supply: (a) the actual date(s) any targeting logic changed, and (b) account-level (not just campaign-level) treatment assignment. Until then, the honest answer is: **insufficient data for a reliable counterfactual estimate**, and the cross-sectional proxy we could run found no effect (p = 0.79).
