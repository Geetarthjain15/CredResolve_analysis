const fs = require("fs");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell,
  WidthType, ShadingType, BorderStyle, AlignmentType, Header, Footer, PageNumber,
} = require("docx");

const NAVY = "37124F";      // deep plum, matches dashboard --accent-deep
const ACCENT = "6423B0";
const MUTED = "5C4D71";
const HAIR = "D2C2E6";

function h(text, opts={}) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 200, after: 80 },
    children: [new TextRun({ text, bold: true, color: NAVY, size: 22 })],
  });
}
function p(runsOrText, opts={}) {
  const children = typeof runsOrText === "string" ? [new TextRun({ text: runsOrText, size: 19 })] : runsOrText;
  return new Paragraph({ spacing: { after: opts.after ?? 100 }, children });
}
function bullet(runsOrText) {
  const children = typeof runsOrText === "string" ? [new TextRun({ text: runsOrText, size: 19 })] : runsOrText;
  return new Paragraph({ bullet: { level: 0 }, spacing: { after: 40 }, children });
}
function b(text) { return new TextRun({ text, bold: true, size: 19 }); }
function t(text) { return new TextRun({ text, size: 19 }); }
function mono(text) { return new TextRun({ text, size: 18, font: "Consolas" }); }

const title = new Paragraph({
  spacing: { after: 40 },
  children: [new TextRun({ text: "Collections Recovery: What Actually Happened", bold: true, size: 32, color: NAVY })],
});
const subtitle = new Paragraph({
  spacing: { after: 200 },
  border: { bottom: { color: HAIR, space: 4, style: BorderStyle.SINGLE, size: 8 } },
  children: [new TextRun({ text: "Executive Memo — Data Analyst Assignment  |  Golden dataset, Jan–Jul 2026 (7 complete months)", size: 18, color: MUTED, italics: true })],
});

function statRow(cells) {
  return new TableRow({
    children: cells.map((c, i) => new TableCell({
      width: { size: 25, type: WidthType.PERCENTAGE },
      shading: i === 0 ? undefined : { type: ShadingType.CLEAR, fill: "F4EEFA" },
      margins: { top: 60, bottom: 60, left: 100, right: 100 },
      children: [new Paragraph({ children: [new TextRun({ text: c.text, bold: c.bold||false, size: 17, color: c.color||"1F1229" })] })],
    })),
  });
}

const roiTable = new Table({
  width: { size: 9000, type: WidthType.DXA },
  columnWidths: [2300, 2300, 2300, 2100],
  rows: [
    new TableRow({ tableHeader: true, children: ["Scenario","Incrementality","Year-1 incremental recovery","ROI on ₹10 Cr"].map(text =>
      new TableCell({ width:{size:2300,type:WidthType.DXA}, shading:{type:ShadingType.CLEAR, fill:"37124F"},
        margins:{top:60,bottom:60,left:100,right:100},
        children:[new Paragraph({children:[new TextRun({text, bold:true, size:16, color:"FFFFFF"})]})] }))
    }),
    new TableRow({ children: ["Downside (3%)","3%","₹5.5 Cr","−45%"].map((text,i) =>
      new TableCell({ width:{size:2300,type:WidthType.DXA}, margins:{top:50,bottom:50,left:100,right:100},
        children:[new Paragraph({children:[new TextRun({text, size:17})]})] }))
    }),
    new TableRow({ children: ["Base case (8%)","8%","₹14.7 Cr","+47%"].map((text,i) =>
      new TableCell({ width:{size:2300,type:WidthType.DXA}, shading:{type:ShadingType.CLEAR, fill:"EFE4FA"}, margins:{top:50,bottom:50,left:100,right:100},
        children:[new Paragraph({children:[new TextRun({text, size:17, bold:true})]})] }))
    }),
    new TableRow({ children: ["Upside (15%)","15%","₹27.5 Cr","+175%"].map((text,i) =>
      new TableCell({ width:{size:2300,type:WidthType.DXA}, margins:{top:50,bottom:50,left:100,right:100},
        children:[new Paragraph({children:[new TextRun({text, size:17})]})] }))
    }),
  ],
});

const doc = new Document({
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 720, bottom: 720, left: 900, right: 900 } } },
    headers: {},
    footers: {
      default: new Footer({ children: [ new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [ new TextRun({ text: "Full evidence: reports/data_quality_report.md, reports/performance_reconstruction.md, reports/statistical_investigation.md, reports/investment_recommendation.md  •  Page ", size: 14, color: MUTED }),
                    new TextRun({ children: [PageNumber.CURRENT], size: 14, color: MUTED }) ]
      })]})
    },
    children: [
      title, subtitle,

      h("What happened"),
      p([b("Recovery is flat, not improving."), t(" Seven complete months of Golden (de-duplicated) recovery data show no statistically detectable trend — a linear regression across Jan–Jul returns p = 0.89. The reported “11% month-on-month improvement” is real as arithmetic (March was 11.0% above February) but not real as a signal: February was the low point of the window (−9.1% vs. January), so March’s “improvement” is a rebound to roughly where January already was — March is only +0.9% above January. Every headline metric we reconstructed tells the same story: contact rate (22.5–24.0%), PTP rate (13.9–16.6%), PTP kept rate (48.5–50.7%), and recovery per agent-hour (₹16.1k–₹17.0k) all move within normal month-to-month noise, not trend.")]),

      h("Why it happened"),
      p([t("We tested every driver the assignment asked about — agent, agent tenure, telephony vendor, channel, campaign, attempt frequency, portfolio mix, targeting-strategy proxy, and targeting priority — and "), b("none showed an effect distinguishable from statistical noise."), t(" Agent-to-agent variance in answer rate (std 4.3%) matches pure sampling noise (expected 4.2%) almost exactly. All 15 telephony vendors perform identically (19.3–20.5% answer rate). Portfolio mix (risk segment, loan type) is stable within ±3pp every month. As a final, more rigorous check, a "), b("multivariate logistic regression on 89,071 account-months, standard errors clustered by account"), t(" — controlling for month, risk segment, loan type, DPD bucket, attempt count, and channel touches simultaneously — confirms the month effects are jointly indistinguishable from zero (cluster-robust Wald p = 0.659). A power analysis confirms the test could have caught an effect this size: 80% power to detect a ±0.94pp (≈12% relative) swing, versus ≈ 0.65pp actually observed. Geography and language could not be tested: 77% of borrowers have internally conflicting city/phone/email data, and no language field exists in the source at all.")]),

      h("How confident are we"),
      bullet([b("High confidence"), t(" the 11% figure is not evidence of a sustained trend — confirmed by simple trend tests and a cluster-robust multivariate regression that a power analysis shows was strong enough to detect an effect of that scale.")]),
      bullet([b("High confidence"), t(" the previously reported recovery figure was inflated — 500 duplicate payment rows overstated recovery by ₹2.59 Cr (1.93%), now corrected in the Golden dataset.")]),
      bullet([b("Low confidence"), t(" in any campaign-level or channel-level attribution claim — 68% of successful payments have no traceable campaign touch within 30 days, and the attribution window choice changes the attributed campaign for 27% of payments that can be attributed at all.")]),
      bullet([b("Escalated, unresolved:"), t(" account status disagrees between the core dimension table and the event log for 85.7% of accounts with history — no data-level way to pick a winner; needs an Engineering decision.")]),

      h("What we should do"),
      p([t("Retire the “11% MoM” headline and replace it with a control-chart view of recovery (mean ± 1 std dev) so a normal-noise month is never again reported as a result. Fix the duplicate-payment and disposition-code-synonym issues in the reporting pipeline (both already fixed in the Golden dataset delivered with this analysis). Escalate the accounts.status vs. event-log conflict to Engineering — it affects every denominator-based metric in the business.")]),
      p([t("For the ₹10 Cr investment: deploy it as a "), b("gated two-phase bet on WhatsApp / digital engagement"), t(" — the one lever with even a weak, directional positive signal, and by far the cheapest and most reversible to test. 86% of the book is already WhatsApp-reachable but touched only once every 13 weeks; frequency, not reach, is the binding constraint.")]),
      bullet([b("Phase 0 (₹1.2 Cr, months 1–3): "), t("a randomized controlled pilot — 3x cadence + AI-personalized sequencing on ~13,000 accounts vs. a held-out control, pre-registered 14-day outcome window.")]),
      bullet([b("Phase 1 (₹8.8 Cr, months 4–15): "), t("scaled to the full 30,000-account book — released only if Phase 0 shows a statistically significant, positive lift. If it doesn’t, the loss is capped at 12% of the budget, not all of it.")]),

      h("Expected financial impact"),
      p([t("Because the underlying incrementality of digital cadence has not been measured — only weakly, non-significantly suggested — we present a range rather than a single number:")], {after:80}),
      roiTable,
      p([t(" ")], {after:40}),
      p([b("Bottom line: "), t("do not commit the full ₹10 Cr on the strength of an untested assumption — that is exactly the mistake behind the “11% MoM” headline this memo corrects. Spend 12% of the budget to find out for certain, then scale only what is proven.")]),
    ],
  }],
});

Packer.toBuffer(doc).then(buf => fs.writeFileSync("executive_memo.docx", buf));
