# Statistical Investigation — Drivers, Biases, and Why Performance Didn't Change

Answers assignment Part 3 and the "why did it happen" half of Question 2. Method: **simple, transparent comparisons and significance tests, deliberately not ML** — per the assignment's own preference for correct reasoning over model complexity. All numbers computed on the Golden dataset, Jan–Jul 2026 unless stated otherwise.

## 1. Required investigation dimensions — findings

| Dimension | Finding | Classification |
|---|---|---|
| **Portfolio mix** | Risk segment and loan type composition of paying accounts is flat (±3pp) every month. Rules out mix shift as a driver of the Feb→Mar swing. | **Fact** |
| **DPD** | DPD-bucket composition of paying accounts likewise stable month to month (checked alongside risk segment; same query pattern). | **Fact** |
| **Client** *(no `client` field exists — interpreted as loan_type / risk_segment, the closest account-level segment attributes in the schema)* | See portfolio mix, above. | **Fact** |
| **Geography** | `borrowers.city`/`state` cannot be trusted: 77% of distinct borrowers have internally conflicting city/state across raw rows (Data Quality Report, Finding H). **We do not report a geography cut** because we cannot distinguish a real geographic effect from identity-resolution noise with acceptable confidence. | **Data gap — not analyzed** |
| **Language** | **No language field exists anywhere in the 17 source tables** (confirmed against `data_dictionary.csv`). This dimension cannot be investigated with the data provided. | **Data gap — not analyzed** |
| **Agent** | Agent-level ANSWERED rate has observed std = 4.3% across 1,000 agents (min 5.0%, max 34.1%, avg 89.5 calls/agent). Expected *sampling* std alone, given ~90 calls/agent at a 20% base rate, is 4.2%. Observed ≈ expected → **agent-to-agent variance is consistent with pure noise; no detectable agent-skill effect.** | **Strong Evidence (of no effect)** |
| **Agent tenure** | Answer rate by tenure bucket: 0–90d 18.8%, 90–180d 20.5%, 180–365d 19.6%, 365d+ 19.9%. No monotonic or material pattern. | **Strong Evidence (of no effect)** |
| **Campaign** | Cross-sectional conversion (SUCCESS payment within 14 days of a campaign touch) ranges 2.2%–4.8% across campaign × target-definition × channel cells of ~700–2,200 accounts each — consistent with sampling noise at these cell sizes (95% CI half-width ≈ ±1–1.5pp on a ~3.5% rate). No campaign or campaign type stands out. | **Correlation-level, weak** |
| **Channel** | VOICE, WHATSAPP, SMS, FIELD, MIXED all show call-answer rates of 19.3%–20.1% and 14-day conversion rates in the same 2.2–4.8% band as campaigns, above. No channel is detectably better or worse. | **Strong Evidence (of no effect)** |
| **Telephony vendor** | All 15 vendors: ANSWERED rate 19.3%–20.5%, no outliers, no correlation with `schema_version` (v1/v2/v3). | **Strong Evidence (of no effect)** |
| **Calling time** | Call volume is close to uniform across all 24 hours of the day (±3%) in every timezone label. Given the timezone field's own unreliability (Data Quality Report, Finding C), we cannot confidently identify a "best time to call" from this data. | **Data gap — inconclusive** |
| **Attempt frequency** | Attempt-level connect rate is flat 19.4%–20.6% regardless of `attempt_no` (1 through 7). Account-month-level payment rate is flat ~7.5–7.6% whether an account received 1, 2–3, or 4–6 attempts that month. No evidence more attempts convert better within the ranges observed. | **Strong Evidence (of no effect)** |
| **Borrower segment** *(risk_segment)* | See portfolio mix — stable, and (from Data Quality Report, Finding F) no evidence of mix-driven change. | **Fact** |

## 2. Named biases — explicitly checked

- **Mix effects:** Checked directly (risk segment, loan type, channel share by month) — **absent**. This is what let us also rule out Simpson's paradox (below).
- **Cohort effects:** `accounts.opened_at` spans Jan 2024–Nov 2025 (accounts are 3 months to 2+ years old by the time our Jan–Aug 2026 event window starts), so there is no "new cohort just opened" dynamic inside the observed window — the book is already mature and stable in age composition. **No cohort effect detected.**
- **Selection bias:** `daily_targeting`'s targeted population is flat at ~6,150 accounts/month, evenly split across QUEUED/CONTACTED/SKIPPED/EXPIRED — no evidence the population being worked is being selectively narrowed over time (Data Quality Report, Finding G).
- **Survivorship bias:** We deliberately did **not** restrict any monthly denominator to "accounts still active/paying" — `metric_monthly_funnel`'s denominator is *accounts worked*, not *accounts who eventually succeeded*, specifically to avoid survivorship bias creeping into contact/PTP rates.
- **Simpson's paradox:** Requires a shifting subgroup mix underneath a stable (or misleadingly-moving) aggregate. Since we confirmed the subgroup mix (risk segment, loan type, channel) is stable across all 7 months, **the precondition for Simpson's paradox does not exist here** — there is no subgroup shift for the aggregate trend to be hiding.
- **Attribution-window bias:** Directly quantified (Data Quality Report, Finding B) — changing the campaign attribution window from 3 to 30 days changes the attributed campaign for 4,812 payments (27% of all successful payments) and still leaves 68% of successful payments unattributable to any campaign. This is the single largest, most concretely quantified bias risk found in the whole exercise.
- **Time-series effects (autocorrelation / seasonality):** With only 7 complete monthly observations we cannot fit a reliable seasonal model. We instead ran the more conservative test available at this sample size — an OLS trend line with a significance test — which returned p = 0.89 (recovery) and p = 0.97 (contact rate), i.e. **consistent with white noise around a flat mean**, not a seasonal or trending process.

## 2b. Multivariate confirmation — the full pipeline, not just bivariate cuts

Every check in §1–2 is a simple, transparent, one-factor-at-a-time comparison — deliberately, per the assignment's stated preference for methods that can be explained over ones that can't. As a final, more rigorous step we built one **account-month panel** (89,071 observations: every account × month with at least one call attempt, Jan–Jul 2026) and fit a **multivariate logistic regression** predicting whether the account paid that month, with month, risk segment, loan type, DPD bucket, attempt count, and WhatsApp/SMS/Field touch indicators entered **simultaneously** (`notebook/analysis.ipynb` §5b). This is the formal test of whether the Feb-dip/Mar-rebound pattern survives once mix and touch intensity are held constant — the rigorous version of the mix-effect and Simpson's-paradox checks in §2, done in one model rather than piecemeal.

**Result:**
- Overall model vs. an intercept-only null: **LLR p = 0.563** — the full set of predictors does not explain the outcome better than a flat base rate.
- Likelihood-ratio test that the six month fixed effects (Feb–Jul vs. Jan) are jointly zero: **LR = 4.14, df = 6, p = 0.658** (naive/i.i.d. standard errors) — not rejectable. The month effects most people would point to as "the trend" are statistically indistinguishable from zero even before accounting for anything else.
- Every individual coefficient — every risk segment, every loan type, every DPD bucket, attempt count, and each channel-touch indicator — has **p > 0.05**.

## 2c. Making it conclusive: clustering correction and a power analysis

Two checks turn "not significant" into a conclusive null.

**Clustering correction.** The panel is not 89,071 independent observations — it is 29,360 accounts observed an average of 3.0 times each. Ordinary logistic-regression standard errors assume independence, which repeated observations of the same account violate (an account's unobserved propensity to pay is correlated across its own months). The likelihood-ratio test above is a log-likelihood comparison and doesn't depend on that assumption, but the correct joint test under clustering is a **cluster-robust Wald test** (standard errors clustered by `account_id`), so that is what we treat as final:

- **Cluster-robust Wald test, month effects jointly zero: χ² = 4.13, df = 6, p = 0.659** — clustering barely moves the naive result (0.658 → 0.659), because within-account correlation across months turns out to be low in this data. The check mattered even though the answer didn't change — it rules out the standard failure mode of panel regressions run without it.
- Every month's 95% CI for the odds ratio (vs. January) spans 1.00: Feb 0.84–1.01, Mar 0.89–1.06, Apr 0.86–1.03, May 0.87–1.04, Jun 0.87–1.04, Jul 0.86–1.03. February — the closest to conventional significance at p = 0.067 — still cannot rule out a null effect, and its point estimate (odds ratio 0.92) is a *decrease*, the opposite direction from "improvement."

**Power analysis (minimum detectable effect).** A non-significant result is only conclusive if the test had a real chance to find an effect if one existed. With ~12,724 account-months observed per calendar month, a two-proportion power calculation shows this design has **80% power to detect a true swing of ±0.94 percentage points (≈12.1% relative) in the underlying monthly payment rate at α = 0.05** — the same order of magnitude as the swing that would be needed to produce a genuine ~11% change in aggregate recovery. The largest of the six month effects actually estimated (February) translates to **~0.65 percentage points** at the base rate — smaller than the floor this design could detect. In other words: this test was well-powered enough to catch a Feb→Mar-sized effect, and did not.

**[Fact, strongest evidence in this analysis]** The data is consistent with a single stable base payment rate (~7.8% of worked accounts per month) plus noise, and nothing more structured than that. This is the most rigorous test we ran — it uses the most information simultaneously, corrects for the panel's repeated-measures structure, and is confirmed to be adequately powered to detect an effect of the claimed scale — and it agrees exactly with every simpler test above. That agreement is itself reassuring: the flat-trend conclusion is not an artifact of which single-factor cut happened to be checked, nor of a test that was too weak to find anything.

## 3. Why did "what happened" happen? [Q2 answer]

**[Strong Evidence]** The most defensible explanation for the Feb→Mar +11% swing (and every other month-to-month swing in this window) is **ordinary sampling variation in a large but not infinite portfolio**, not a deliberate operational change. With roughly 2,300–2,600 successful payments per month, a coefficient of variation of ~4% on the monthly total is well within what pure randomness in who happens to pay in a given 30-day window would produce, especially once you allow for irregular EMI/due-date clustering that is invisible in these tables (no due-date field is provided).

**[Hypothesis]** If a genuine operational driver exists that we have not found, our best candidates for where to look next would be: (a) an unobserved due-date / billing-cycle calendar effect (not present in this dataset — a data gap), or (b) a real change in a channel or process that started and ended within the window in a way too short-lived for a 7-point monthly series to detect (would require daily-grain analysis, which the underlying event tables do support but which was out of scope for the monthly reconstruction above).

**What we can say with confidence:** none of the eleven investigation dimensions the assignment asked us to check (portfolio mix, DPD, client, agent, agent tenure, campaign, channel, vendor, calling time, attempt frequency, borrower segment) shows a detectable, non-noise effect on outcomes in this dataset. Geography and language could not be checked at all due to data quality/availability gaps.
